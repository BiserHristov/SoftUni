﻿namespace _01.Vehicles.Models.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
