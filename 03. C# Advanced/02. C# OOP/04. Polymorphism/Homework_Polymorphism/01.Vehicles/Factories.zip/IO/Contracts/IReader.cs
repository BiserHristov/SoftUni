﻿namespace _01.Vehicles.Models.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
