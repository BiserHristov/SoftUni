﻿namespace _02.VehicleExtension.Models.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
