﻿namespace _02.VehicleExtension.Models.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
