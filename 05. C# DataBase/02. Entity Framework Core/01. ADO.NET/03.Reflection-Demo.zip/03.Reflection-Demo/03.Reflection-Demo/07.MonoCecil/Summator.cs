﻿namespace MonoCecil
{
    public class Summator
    {
        public long Sum(int a, int b)
        {
            return a + b;
        }
    }
}
