﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.Models.DataTransferObjects
{
    public class CategoriesProductsInputModel
    {
        public int CategoryId { get; set; }
        public int ProductId { get; set; }
    }

    
}
