﻿namespace MiniORM.App
{
    using Data;
    using System.Linq;
    using Data.Entities;

    public class StartUp
    {
        public static void Main()
        {
            string connectionString = @"Server=.\SQLEXPRESS; database= MiniORM; Integrated Security = true;";

            //Open connection and initialize dbContext
            SoftUniDbContext dbContext = new SoftUniDbContext(connectionString);

            //ADD A
            dbContext.Employees.Add(new Employee 
            {
                FirstName = "A",
                LastName = "B",
                DepartmentId = dbContext.Departments.First().Id,
                IsEmployed = true

            });

            //Find A
            Employee employee = dbContext.Employees.Where(x => x.FirstName == "A")?.FirstOrDefault();

            
            if (employee != null)
            {
                //Change his name to L!
                employee.FirstName = "L";

                //Save changes
                dbContext.SaveChanges();
            }
        }
    }
}
