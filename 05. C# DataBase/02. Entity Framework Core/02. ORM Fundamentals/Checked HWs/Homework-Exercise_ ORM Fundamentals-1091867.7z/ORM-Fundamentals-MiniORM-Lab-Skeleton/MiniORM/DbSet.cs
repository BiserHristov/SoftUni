﻿namespace MiniORM
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;
    public class DbSet<TEntity> : ICollection<TEntity>
        where TEntity : class, new()
    {
        private IList<TEntity> entities;

        private ChangeTracker<TEntity> changeTracker;

        internal DbSet(IEnumerable<TEntity> inputEntities)
        {
            this.Entities = inputEntities.ToList();
            this.ChangeTracker = new ChangeTracker<TEntity>(inputEntities);
        }

        internal IList<TEntity> Entities
        {
            get
            {
                return this.entities;
            }
            set
            {
                this.entities = value;
            }
        }

        internal ChangeTracker<TEntity> ChangeTracker
        {
            get
            {
                return this.changeTracker;
            }
            set
            {
                this.changeTracker = value;
            }
        }

        public int Count => this.Entities.Count;

        public bool IsReadOnly => this.Entities.IsReadOnly;

        public IEnumerator<TEntity> GetEnumerator()
        {
            return this.Entities.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }

        public void Add(TEntity item)
        {
            if (item == null)
            {
                throw new ArgumentNullException(nameof(item), "Item cannot be null!");
            }

            this.Entities.Add(item);
            this.ChangeTracker.Add(item);
        }

        public void Clear()
        {
            while (this.Entities.Any())
            {
                TEntity currentEntity = this.Entities.First();
                this.Remove(currentEntity);
            }
        }

        public bool Contains(TEntity item)
        {
            if (item == null)
            {
                throw new ArgumentNullException(nameof(item), "Item cannot be null!");
            }

            return this.Entities.Contains(item); ;
        }

        public void CopyTo(TEntity[] array, int arrayIndex)
        {
            if (array == null)
            {
                throw new ArgumentNullException(nameof(array), "TEntity[] array cannot be null!");
            }

            this.Entities.CopyTo(array, arrayIndex);
        }

        public bool Remove(TEntity item)
        {
            if (item == null)
            {
                throw new ArgumentNullException(nameof(item),"item cannot be null");
            }

            bool isItemRemovedSuccessfully = this.Entities.Remove(item);

            if (isItemRemovedSuccessfully)
            {
                this.ChangeTracker.Remove(item);
            }

            return isItemRemovedSuccessfully;
        }

        public void RemoveRange(IEnumerable<TEntity> entityRange)
        {
            if (entityRange == null)
            {
                throw new ArgumentNullException(nameof(entityRange), "IEnumerable<TEntity> entityRange cannot be null");
            }

            foreach (TEntity entity in entityRange)
            {
                this.Remove(entity);
            }
        }
    }
}