﻿namespace MiniORM
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Reflection;
    using System.ComponentModel.DataAnnotations;
    internal class ChangeTracker<T>
        where T : class, new()
    {
        private readonly List<T> allEntities;
        private readonly List<T> addedEntities;
        private readonly List<T> removedEntities;

        internal ChangeTracker(IEnumerable<T> entities)
        {
            this.addedEntities = new List<T>();
            this.removedEntities = new List<T>();
            this.allEntities = CloneEntities(entities);
        }

        private static List<T> CloneEntities(IEnumerable<T> entities)
        {
            List<T> clonedEntities = new List<T>();

            PropertyInfo[] propertiesToClone = typeof(T)
                                                        .GetProperties()
                                                        .Where(p => DbContext.AllowedSqlTypes.Contains(p.PropertyType))
                                                        .ToArray();

            foreach (T entity in entities)
            {
                T clonedEntity = Activator.CreateInstance<T>();

                foreach (PropertyInfo allowedProperty in propertiesToClone)
                {
                    object value = allowedProperty.GetValue(entity);
                    allowedProperty.SetValue(clonedEntity, value);
                }

                clonedEntities.Add(clonedEntity);
            }
            return clonedEntities;
        }

        public IReadOnlyCollection<T> AllEntities => this.allEntities.AsReadOnly();

        public IReadOnlyCollection<T> AddedEntities => this.addedEntities.AsReadOnly();

        public IReadOnlyCollection<T> RemovedEntities => this.removedEntities.AsReadOnly();

        public void Add(T entity)
        {
            this.addedEntities.Add(entity);
        }

        public void Remove(T entity)
        {
            this.removedEntities.Add(entity);
        }

        public IEnumerable<T> GetModifiedEntities(DbSet<T> dbSet)
        {
            List<T> modifiedEntities = new List<T>();

            PropertyInfo[] primaryKeys = typeof(T)
                                                .GetProperties()
                                                .Where(pi => pi.HasAttribute<KeyAttribute>())
                                                .ToArray();

            foreach (T currentEntity in this.AllEntities)
            {
                object[] primaryKeyValues = GetPrimaryKeyValues(primaryKeys, currentEntity).ToArray();

                T entity = dbSet.Entities
                                            .Single(ent => GetPrimaryKeyValues(primaryKeys, ent)
                                            .SequenceEqual(primaryKeyValues));

                bool isModified = IsModified(currentEntity, entity);
                
                if (isModified)
                {
                    modifiedEntities.Add(entity);
                }
            }

            return modifiedEntities;
        }

        private static IEnumerable<object> GetPrimaryKeyValues(IEnumerable<PropertyInfo> primaryKeys, T entity)
        {
            return primaryKeys.Select(pk => pk.GetValue(entity));
        }

        private static bool IsModified(T originalEntity, T proxyEntity)
        {
            IEnumerable<PropertyInfo> monitoredPropertyInfos = typeof(T)
                .GetProperties()
                .Where(pi => DbContext.AllowedSqlTypes.Contains(pi.PropertyType));

            PropertyInfo[] modifiedPropertyInfos = monitoredPropertyInfos
                .Where(pi => !Equals(pi.GetValue(originalEntity), pi.GetValue(proxyEntity)))
                .ToArray();

            bool isModified = modifiedPropertyInfos.Any();

            return isModified;
        }
    }
}