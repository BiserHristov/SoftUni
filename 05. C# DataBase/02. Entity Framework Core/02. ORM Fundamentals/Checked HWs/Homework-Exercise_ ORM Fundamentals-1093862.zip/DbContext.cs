﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;

namespace MiniORM
{
	public abstract class DbContext
    {
        private readonly DatabaseConnection connection;

        private readonly Dictionary<Type, PropertyInfo> dbSetProperties;

        internal static readonly Type[] AllowedSqlTypes =
        {
            typeof(int),
            typeof(string),
            typeof(ulong),
            typeof(uint),
            typeof(long),
            typeof(decimal),
            typeof(bool),
            typeof(DateTime),
        };

        protected DbContext(string connectionString)
        {
            this.connection = new DatabaseConnection(connectionString);

            this.dbSetProperties = this.DiscoverDbSets();

            using( new ConnectionManager(connection))
            {
                this.InitializeDbSets();
            }

            this.MapAllRelations();
        }

        public void SaveChanges()
        {
            object[] dbSets = this.dbSetProperties
                .Select(p => p.Value.GetValue(this)).ToArray();

            foreach (IEnumerable<object> dbSet in dbSets)
            {
                object[] invalidEntities = dbSet.Where(entity => !IsObjectValid(entity)).ToArray();

                if (invalidEntities.Any())
                {
                    throw new InvalidOperationException($"{invalidEntities.Length} Invalid Entities found in {dbSet.GetType().Name}!");
                }
            }

            using(new ConnectionManager(this.connection))
            {

                using(SqlTransaction transaction =
                    this.connection.StartTransaction())
                {

                    foreach (IEnumerable dbset in dbSets)
                    {
                        Type dbSetType = dbset.GetType().GetGenericArguments().First();

                        MethodInfo persistMethod = typeof(DbContext).GetMethod("Persist",
                            BindingFlags.Instance | BindingFlags.NonPublic)
                            .MakeGenericMethod(dbSetType);

                        try
                        {
                            persistMethod.Invoke(this, new object[] {dbset});
                        }
                        catch (TargetInvocationException tie)
                        {

                            throw tie.InnerException;
                        }
                        catch (InvalidOperationException)
                        {
                            transaction.Rollback();
                            throw;
                        }
                        catch (SqlException)
                        {
                            transaction.Rollback();
                            throw;
                        }

                    }
                    transaction.Commit();
                }
            }
        }
        private void Persist<TEntity>(DbSet<TEntity> dbSet)
            where TEntity : class , new ()
        {

            //взимаме името на колоната
            var tableName = this.GetTableName(typeof(TEntity));

            //в този масив ще пазим имената на всички колони
            string[] colums = this.connection.FetchColumnNames(tableName).ToArray();

            if (dbSet.ChangeTracker.Added.Any())
            {
                this.connection.InsertEntities(dbSet.ChangeTracker.Added,
                    tableName, colums);
            }

            //взимаме всички модифицирани ентитита
            TEntity[] modifiedEntities = dbSet.ChangeTracker
                .GetModifiedEntities(dbSet).ToArray();

            //ако има промени 
            if (modifiedEntities.Any())
            {
                this.connection.UpdateEntities(modifiedEntities, tableName, colums);

            }

            if (dbSet.ChangeTracker.Removed.Any())
            {
                this.connection.DeleteEntities(dbSet.ChangeTracker.Removed, tableName, colums);
            }

        }

        private bool IsObjectValid(object e)
        {
            ValidationContext validationContext = new ValidationContext(e);
            List<ValidationResult> validationErrors = new List<ValidationResult>();

            bool validationResult = Validator
                .TryValidateObject(e, validationContext, validationErrors);

            return validationResult;
       }

        private void MapAllRelations()
        {
            foreach (KeyValuePair<Type, PropertyInfo> dbSetProperty in this.dbSetProperties)
            {
                Type dbSetType = dbSetProperty.Key;

                MethodInfo mapRelationsGenericMethod = typeof(DbContext)
                    .GetMethod("MapRelations", BindingFlags.Instance | BindingFlags.NonPublic)
                    .MakeGenericMethod(dbSetType);

                object dbSet = dbSetProperty.Value.GetValue(this);
                mapRelationsGenericMethod.Invoke(this, new object[] { dbSet });

            }

        }
        private void MapRelations<TEntity>(DbSet<TEntity> dbSet)
            where TEntity : class , new()
        {
            Type entityType = typeof(TEntity);

            this.MapNavigationProperties(dbSet);

            PropertyInfo[] collections = entityType.GetProperties()
                .Where(p => p.PropertyType.IsGenericType &&
            p.PropertyType.GetGenericTypeDefinition() == typeof(ICollection<>)).ToArray();

            foreach (PropertyInfo collection  in collections)
            {
                Type collectionType = collection.PropertyType
                    .GetGenericArguments().First();

                MethodInfo mapCollectionsMethod = typeof(DbContext)
                    .GetMethod("MapCollection", BindingFlags.Instance
                                      | BindingFlags.NonPublic)
                    .MakeGenericMethod(entityType,collectionType);
            }
        }

        private void MapNavigationProperties<TEntity>(DbSet<TEntity> dbSet)
            where TEntity : class , new()
        {
            Type entityType = dbSet.GetType();

            PropertyInfo[] foreignKeys = entityType.GetProperties()
                .Where(p => p.HasAttribute<ForeignKeyAttribute>()).ToArray();

            foreach (PropertyInfo foreignKey in foreignKeys)
            {
                string navigationPropertyName = foreignKey.GetCustomAttribute<ForeignKeyAttribute>().Name;

                PropertyInfo navigationProperty = entityType
                    .GetProperty(navigationPropertyName);

                object navigationDbSet = this.dbSetProperties[navigationProperty.PropertyType]
                    .GetValue(this);

                PropertyInfo navigationPrimaryKey =
                    navigationProperty.PropertyType.GetProperties()
                    .First(p => p.HasAttribute<KeyAttribute>());

                foreach (var entity in dbSet)
                {
                    object foregnKeyValue = foreignKey.GetValue(entity);

                    object navigationPropertyValue = ((IEnumerable<object>)navigationDbSet)
                        .First(currentNavigationProperty => navigationPrimaryKey.GetValue(currentNavigationProperty)
                        .Equals(foregnKeyValue));

                    navigationProperty.SetValue(entity, navigationPropertyValue);
                }
            }  


        }

        private IEnumerable<TEntity> LoadTableEntities<TEntity>()
            where TEntity : class 
        {
            Type table = typeof(TEntity);

            var colums = GetEntityColumnNames(table);

            string tableName = GetTableName(table);

            var fechedRows = this.connection
                .FetchResultSet<TEntity>(tableName, colums).ToArray();

            return fechedRows;
        }

        private object GetEntityColumnNames(Type tables)
        {
            string tableName = GetTableName(tables);

            string[] Dbcolumns = this.connection.FetchColumnNames(tableName).ToArray();

            string[] columns = tables.GetProperties()
                .Where(p => Dbcolumns.Contains(p.Name) &&
                !p.HasAttribute<NotMappedAttribute>() &&
                AllowedSqlTypes.Contains(p.PropertyType))
                .Select(p => p.Name).ToArray();

            return columns;
        }

        private string GetTableName(Type tableType)
        {
            string tableName = ((TableAttribute)Attribute.GetCustomAttribute(tableType, typeof
                (TableAttribute))).Name;

            if(tableName == null)
            {
                tableName = this.dbSetProperties[tableType].Name;
            }
            return tableName;
        }

        private void MapCollection<TDbSet, TCollection>(DbSet<TDbSet> dbSet,
            PropertyInfo collectionProperty)
            where TDbSet : class, new()
            where TCollection : class , new()
        {
            var entityType = typeof(TDbSet);
            var collectionType = typeof(TCollection);

            var primaryKeys = collectionType.GetProperties()
                .Where(p => p.HasAttribute<KeyAttribute>()).ToArray();

            PropertyInfo primaryKey = primaryKeys.First();
            PropertyInfo foreignKey = entityType.GetProperties().First(p => p.HasAttribute<KeyAttribute>());

            bool isManyToMany = primaryKeys.Length >= 2;
            if (isManyToMany)
            {

                primaryKey = collectionType
                    .GetProperties().First(p => collectionType
                    .GetProperty(p.GetCustomAttribute<ForeignKeyAttribute>()
                    .Name).PropertyType == entityType);
                    
            }

            DbSet<TCollection> navigationDbSet = (DbSet<TCollection>)
                this.dbSetProperties[collectionType]
                .GetValue(this);

            foreach (TDbSet entity  in dbSet)
            {
                object primaryKeyValue = foreignKey.GetValue(entity);

                ICollection[] navigationEntities = (ICollection[])navigationDbSet
                    .Where(navigationEntity => primaryKey.GetValue(navigationEntity)
                    .Equals(primaryKeyValue)).ToArray();

                ReflectionHelper.ReplaceBackingField(entity, collectionProperty.Name, navigationEntities);
            }

        }
        private void InitializeDbSets()
        {
            foreach ( KeyValuePair<Type,PropertyInfo> dbSet in this.dbSetProperties)
            {
                Type dbSetType = dbSet.Key;
                PropertyInfo dbSetProperty = dbSet.Value;

                MethodInfo populateMethod = typeof(DbContext)
                    .GetMethod("PopulateDbSet", BindingFlags.Instance |
                    BindingFlags.NonPublic).MakeGenericMethod(dbSetType);

                populateMethod.Invoke(this, new object[] { dbSetProperty });
            }
        }

        private void PersistDbSet<TEntity>(PropertyInfo dbSet)
            where TEntity : class, new()
        {
            IEnumerable<TEntity> entities = this.LoadTableEntities<TEntity>();

            DbSet<TEntity> dbSetInstance = new DbSet<TEntity>(entities);

            ReflectionHelper.ReplaceBackingField(this, dbSet.Name, dbSetInstance);
        }
        private Dictionary<Type, PropertyInfo> DiscoverDbSets()
        {
            var dbSets = this.GetType().GetRuntimeProperties()
                 .Where(p => p.PropertyType.GetGenericTypeDefinition() == typeof(DbSet<>))
                 .ToDictionary(p => p.PropertyType.GetGenericArguments().First(),
                 p => p);

            return dbSets;
        }
    }
}