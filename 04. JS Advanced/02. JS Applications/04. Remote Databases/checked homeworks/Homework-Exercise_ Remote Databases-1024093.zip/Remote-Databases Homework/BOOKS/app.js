
let loadAllBooksBtn = document.getElementById(`loadBooks`);
let submitBtn = document.getElementById(`submit`);
let editBtn = document.getElementById(`edit`);

let titleEL = document.getElementById(`title`);
let authorEL = document.getElementById(`author`);
let isbnEL = document.getElementById(`isbn`);

let bookDisplay = document.getElementsByTagName(`tbody`)[0];

loadAllBooksBtn.addEventListener(`click`, async function (e) {
    let booksURL = `https://api.backendless.com/63504CD3-2C67-2212-FFC2-EA3301590000/084F5FF0-604B-4792-92EF-026FC3F799F8/data/books`;

    await fetch(booksURL)
        .then(res => res.json())
        .then(data => renderBooks(data));

});

submitBtn.addEventListener(`click`, async function (e) {
    e.preventDefault();

    let booksURL = `https://api.backendless.com/63504CD3-2C67-2212-FFC2-EA3301590000/084F5FF0-604B-4792-92EF-026FC3F799F8/data/books`;
    let title = titleEL.value;
    let author = authorEL.value;
    let isbn = isbnEL.value;

    if (title === `` || author === `` || isbn === ``) {
        return;
    }

    await fetch(booksURL,
        {
            method: "POST",
            body: JSON.stringify({ author: author, title: title, isbn: isbn })
        })


    titleEL.value = ``;
    authorEL.value = ``;
    isbnEL.value = ``;
});




function renderBooks(data) {
    let dataArr = Array.from(data);
    bookDisplay.innerHTML = ``;


    dataArr.forEach(book => {
        let tr = ce(`tr`);
        let nameTd = ce(`td`, `${book.title}`);
        tr.appendChild(nameTd);
        let authorTd = ce(`td`, `${book.author}`);
        tr.appendChild(authorTd);
        let isbnTd = ce(`td`, `${book.isbn}`);
        tr.appendChild(isbnTd);

        let buttonsTd = ce(`td`);
        tr.appendChild(buttonsTd);

        let editBtn = ce(`button`, `Edit`);

        editBtn.addEventListener(`click`, (e) => {
            document.getElementById(`editForm`).style.display = `block`;

            document.getElementById(`editBtn`).addEventListener(`click`, (e) => {
                e.preventDefault();

                let title = document.getElementById(`newtitle`).value;
                let author = document.getElementById(`newauthor`).value;
                let isbn = document.getElementById(`newisbn`).value;

                if (title === `` || author === `` || isbn === ``) {
                    return;
                }

                let bookURL = `https://api.backendless.com/63504CD3-2C67-2212-FFC2-EA3301590000/084F5FF0-604B-4792-92EF-026FC3F799F8/data/books/${book.objectId}`;
                fetch(bookURL,
                    {
                        method: "PUT",
                        body: JSON.stringify({ author: author, title: title, isbn: isbn })
                    })

                document.getElementById(`newtitle`).value = ``;
                document.getElementById(`newauthor`).value = ``;
                document.getElementById(`newisbn`).value = ``;
                document.getElementById(`editForm`).style.display = `none`;
            })
        })

        buttonsTd.appendChild(editBtn);

        let deleteBtn = ce(`button`, `Delete`);

        deleteBtn.addEventListener(`click`, async () => {
            let bookURL = `https://api.backendless.com/63504CD3-2C67-2212-FFC2-EA3301590000/084F5FF0-604B-4792-92EF-026FC3F799F8/data/books/${book.objectId}`;
            await fetch(bookURL,
                {
                    method: "Delete",
                })
            tr.remove();
        });
        buttonsTd.appendChild(deleteBtn);

        bookDisplay.appendChild(tr);
    });
}




















function ce(el, text, className, id) {
    let e = document.createElement(el);
    if (text) {
        e.textContent = text;
    }
    if (className) {
        e.classList = className;
    }
    if (id) {
        e.id = id;
    }
    return e;
}