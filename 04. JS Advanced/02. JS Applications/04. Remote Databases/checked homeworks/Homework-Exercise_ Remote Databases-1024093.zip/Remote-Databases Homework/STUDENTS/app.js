let idEl = document.getElementById(`id`);
let firstNameEl = document.getElementById(`firstname`);
let secondNameEl = document.getElementById(`secondname`);
let facultyNumberEl = document.getElementById(`facultynumber`);
let gradeEl = document.getElementById(`grade`);

let studentsEl = document.getElementById(`results`).children[1];

let addBtn = document.getElementById(`add`);
let displayBtn = document.getElementById(`display`);




addBtn.addEventListener(`click`, async function (e) {
    e.preventDefault();
    let id = idEl.value;
    let firstName = firstNameEl.value;
    let secondName = secondNameEl.value;
    let facultyNumber = facultyNumberEl.value;
    let grade = gradeEl.value;

    if (isNaN(Number(idEl.value)) || firstNameEl.value === `` || secondNameEl.value === `` || isNaN(Number(facultyNumberEl.value)) || isNaN(Number(gradeEl.value))) {
        return;
    }


    let student = {
        ID: Number(id),
        FirstName: firstName,
        SecondName: secondName,
        FacultyNumber: Number(facultyNumber),
        Grade: Number(grade)
    }

    try {
        const created = await createStudent(student);
    } catch (error) {
        alert(error)
    }





    idEl.value = ``;
    firstNameEl.value = ``;
    secondNameEl.value = ``;
    facultyNumberEl.value = ``;
    gradeEl.value = ``;
});

displayBtn.addEventListener(`click`, async function (e) {
    e.preventDefault();

    try {
        const displayed = await getStudents();
    } catch (error) {
        alert(error)
    }
})













let studendsURL = `https://api.backendless.com/63504CD3-2C67-2212-FFC2-EA3301590000/084F5FF0-604B-4792-92EF-026FC3F799F8/data/students`;

async function getStudents() {

    studentsEl.innerHTML = ``;

    const response = await fetch(studendsURL);
    const students = await response.json();

    let studentsArr = Array.from(students)

    /*
    sortedStudents.sort(function (a, b) {
        return a.ID.localeCompare(b.ID);
    });
*/

    Object.keys(studentsArr).forEach(key => {

        let tr = ce(`tr`);
        let IDTh = ce(`th`, `${studentsArr[key].ID}`);
        tr.appendChild(IDTh);
        let firstNameTh = ce(`th`, `${studentsArr[key].FirstName}`);
        tr.appendChild(firstNameTh);
        let secondNameTh = ce(`th`, `${studentsArr[key].secondName}`);
        tr.appendChild(secondNameTh);
        let facultyNumberTh = ce(`th`, `${studentsArr[key].FacultyNumber}`);
        tr.appendChild(facultyNumberTh);
        let gradeTh = ce(`th`, `${studentsArr[key].Grade}`);
        tr.appendChild(gradeTh);

        studentsEl.appendChild(tr);
    });


    let sortedStudents = Array.from(studentsEl.children);
    sortedStudents = sortedStudents.sort(function (a, b) {
        return a.children[0].textContent.localeCompare(b.children[0].textContent);
    });

    studentsEl.innerHTML = ``;

    sortedStudents.forEach(element => {
        studentsEl.appendChild(element);
    });


    return students;
}

async function createStudent(student) {
    const createdBook = await fetch(studendsURL, {
        method: 'POST',
        body: JSON.stringify(student)
    });

    return createdBook;
}







function ce(el, text, className, id) {
    let e = document.createElement(el);
    if (text) {
        e.textContent = text;
    }
    if (className) {
        e.classList = className;
    }
    if (id) {
        e.id = id;
    }
    return e;
}