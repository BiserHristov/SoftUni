const studentsContainer = document.getElementById('studentsList');

let studentIdInput = document.getElementById('idInput');
let firstNameInput = document.getElementById('firstName');
let lastNameInput = document.getElementById('lastName');
let facultyNumberInput = document.getElementById('facultyNumber');
let gradeInput = document.getElementById('grade');
let addStudentBtn = document.getElementById('addBtn');

const baseURL = `https://students-f9e3d.firebaseio.com/students.json`;

addStudentBtn.addEventListener('click', addStudent);

function addStudent(e){
    e.preventDefault();

    if (studentIdInput.value == '' || 
    firstNameInput.value == '' || 
    lastNameInput.value == '' || 
    facultyNumberInput.value == '' || 
    gradeInput.value == '') {
        alert('There is incorrect or empty inputs');
        throw new Error();
    }

    let initObj = {
        method: 'POST',
        body: JSON.stringify({
            id: studentIdInput.value,
            firstName: firstNameInput.value,
            lastName: lastNameInput.value,
            facultyNumber: facultyNumberInput.value,
            grade: gradeInput.value 
        })
    }

    fetch(baseURL,initObj);

    if(studentsContainer.textContent != ''){
        studentsContainer.textContent = '';
    }

    fetchAllStudents(baseURL);

    function fetchAllStudents(URL){
        fetch(URL)
            .then(res => res.json())
            .then(data => {
                Object.keys(data)
                    .forEach(key => {
                    let {id, firstName, lastName, facultyNumber, grade} = data[key];

                    let studentTrElement = createElement('tr','');
                    let idElement = createElement('td',`${id}`);
                    let firstNameElement = createElement('td',`${firstName}`);
                    let lastNameElement = createElement('td',`${lastName}`);
                    let facultyNumberElement = createElement('td',`${facultyNumber}`);
                    let gradeElement = createElement('td',`${grade}`);

                    studentTrElement.appendChild(idElement);
                    studentTrElement.appendChild(firstNameElement);
                    studentTrElement.appendChild(lastNameElement);
                    studentTrElement.appendChild(facultyNumberElement);
                    studentTrElement.appendChild(gradeElement);

                    studentsContainer.appendChild(studentTrElement);
                })
            })

        studentIdInput.value = ''; 
        firstNameInput.value = ''; 
        lastNameInput.value = ''; 
        facultyNumberInput.value = ''; 
        gradeInput.value = '';

    } 

    function createElement(elementType, content){
        let element = document.createElement(elementType);
        element.textContent = content;

        return element;
    }
    
}